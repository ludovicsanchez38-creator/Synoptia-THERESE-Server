--
-- PostgreSQL database dump
--

\restrict eDAEehIKNzzMKM7heMiiE8PtY2g5B22ai1AxvgglDEeEiPeAb1KYWvPavDUZCIZ

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: activities; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.activities (
    id character varying NOT NULL,
    contact_id character varying NOT NULL,
    type character varying NOT NULL,
    title character varying NOT NULL,
    description character varying,
    extra_data character varying,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.activities OWNER TO therese;

--
-- Name: activity_logs; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.activity_logs (
    id integer NOT NULL,
    "timestamp" timestamp without time zone NOT NULL,
    action character varying NOT NULL,
    resource_type character varying,
    resource_id character varying,
    details character varying,
    ip_address character varying,
    user_agent character varying
);


ALTER TABLE public.activity_logs OWNER TO therese;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE; Schema: public; Owner: therese
--

CREATE SEQUENCE public.activity_logs_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER SEQUENCE public.activity_logs_id_seq OWNER TO therese;

--
-- Name: activity_logs_id_seq; Type: SEQUENCE OWNED BY; Schema: public; Owner: therese
--

ALTER SEQUENCE public.activity_logs_id_seq OWNED BY public.activity_logs.id;


--
-- Name: agent_messages; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.agent_messages (
    id character varying NOT NULL,
    task_id character varying NOT NULL,
    agent character varying NOT NULL,
    role character varying NOT NULL,
    content character varying NOT NULL,
    tool_calls character varying,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.agent_messages OWNER TO therese;

--
-- Name: agent_tasks; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.agent_tasks (
    id character varying NOT NULL,
    title character varying NOT NULL,
    description character varying,
    status character varying NOT NULL,
    branch_name character varying,
    source_path character varying,
    diff_summary character varying,
    diff_patch character varying,
    files_changed character varying,
    agent_model character varying,
    tokens_used integer NOT NULL,
    cost_eur double precision NOT NULL,
    error character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    merged_at timestamp without time zone
);


ALTER TABLE public.agent_tasks OWNER TO therese;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.audit_logs (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    org_id character varying NOT NULL,
    user_email character varying,
    action character varying NOT NULL,
    resource character varying,
    resource_id character varying,
    details_json character varying,
    ip_address character varying,
    user_agent character varying,
    "timestamp" timestamp without time zone NOT NULL
);


ALTER TABLE public.audit_logs OWNER TO therese;

--
-- Name: board_decisions; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.board_decisions (
    id character varying NOT NULL,
    user_id character varying,
    org_id character varying,
    question character varying NOT NULL,
    context character varying,
    opinions character varying NOT NULL,
    synthesis character varying NOT NULL,
    confidence character varying NOT NULL,
    recommendation character varying NOT NULL,
    mode character varying NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.board_decisions OWNER TO therese;

--
-- Name: calendar_events; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.calendar_events (
    id character varying NOT NULL,
    calendar_id character varying NOT NULL,
    summary character varying NOT NULL,
    description character varying,
    location character varying,
    start_datetime timestamp without time zone,
    end_datetime timestamp without time zone,
    start_date character varying,
    end_date character varying,
    all_day boolean NOT NULL,
    attendees character varying,
    recurrence character varying,
    status character varying NOT NULL,
    synced_at timestamp without time zone NOT NULL
);


ALTER TABLE public.calendar_events OWNER TO therese;

--
-- Name: calendars; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.calendars (
    id character varying NOT NULL,
    user_id character varying,
    org_id character varying,
    account_id character varying,
    summary character varying NOT NULL,
    description character varying,
    timezone character varying NOT NULL,
    "primary" boolean NOT NULL,
    provider character varying NOT NULL,
    remote_id character varying,
    caldav_url character varying,
    caldav_username character varying,
    caldav_password character varying,
    sync_status character varying NOT NULL,
    last_sync_error character varying,
    synced_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.calendars OWNER TO therese;

--
-- Name: code_changes; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.code_changes (
    id character varying NOT NULL,
    task_id character varying NOT NULL,
    file_path character varying NOT NULL,
    change_type character varying NOT NULL,
    diff_hunk character varying,
    explanation character varying,
    approved boolean,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.code_changes OWNER TO therese;

--
-- Name: contacts; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.contacts (
    id character varying NOT NULL,
    user_id character varying,
    org_id character varying,
    first_name character varying,
    last_name character varying,
    company character varying,
    email character varying,
    phone character varying,
    address character varying,
    notes character varying,
    tags character varying,
    extra_data character varying,
    stage character varying NOT NULL,
    score integer NOT NULL,
    source character varying,
    last_interaction timestamp without time zone,
    rgpd_base_legale character varying,
    rgpd_date_collecte timestamp without time zone,
    rgpd_date_expiration timestamp without time zone,
    rgpd_consentement boolean NOT NULL,
    scope character varying NOT NULL,
    scope_id character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.contacts OWNER TO therese;

--
-- Name: conversations; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.conversations (
    id character varying NOT NULL,
    user_id character varying,
    org_id character varying,
    title character varying,
    summary character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.conversations OWNER TO therese;

--
-- Name: deliverables; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.deliverables (
    id character varying NOT NULL,
    project_id character varying NOT NULL,
    title character varying NOT NULL,
    description character varying,
    status character varying NOT NULL,
    due_date timestamp without time zone,
    completed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.deliverables OWNER TO therese;

--
-- Name: email_accounts; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.email_accounts (
    id character varying NOT NULL,
    user_id character varying,
    org_id character varying,
    email character varying NOT NULL,
    provider character varying NOT NULL,
    client_id character varying,
    client_secret character varying,
    access_token character varying,
    refresh_token character varying,
    token_expiry timestamp without time zone,
    scopes character varying,
    imap_host character varying,
    imap_port integer NOT NULL,
    imap_username character varying,
    imap_password character varying,
    smtp_host character varying,
    smtp_port integer NOT NULL,
    smtp_use_tls boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL,
    last_sync timestamp without time zone
);


ALTER TABLE public.email_accounts OWNER TO therese;

--
-- Name: email_labels; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.email_labels (
    id character varying NOT NULL,
    account_id character varying NOT NULL,
    name character varying NOT NULL,
    type character varying NOT NULL,
    color_background character varying,
    color_text character varying,
    messages_total integer NOT NULL,
    messages_unread integer NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.email_labels OWNER TO therese;

--
-- Name: email_messages; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.email_messages (
    id character varying NOT NULL,
    thread_id character varying NOT NULL,
    account_id character varying NOT NULL,
    subject character varying,
    snippet character varying,
    from_email character varying NOT NULL,
    from_name character varying,
    to_emails character varying NOT NULL,
    cc_emails character varying,
    bcc_emails character varying,
    date timestamp without time zone NOT NULL,
    internal_date timestamp without time zone NOT NULL,
    labels character varying NOT NULL,
    is_read boolean NOT NULL,
    is_starred boolean NOT NULL,
    is_important boolean NOT NULL,
    is_draft boolean NOT NULL,
    has_attachments boolean NOT NULL,
    attachment_count integer NOT NULL,
    body_plain character varying,
    body_html character varying,
    size_bytes integer NOT NULL,
    synced_at timestamp without time zone NOT NULL,
    priority character varying,
    priority_score integer,
    priority_reason character varying,
    category character varying
);


ALTER TABLE public.email_messages OWNER TO therese;

--
-- Name: files; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.files (
    id character varying NOT NULL,
    user_id character varying,
    org_id character varying,
    path character varying NOT NULL,
    name character varying NOT NULL,
    extension character varying NOT NULL,
    size integer NOT NULL,
    mime_type character varying,
    content_hash character varying,
    chunk_count integer NOT NULL,
    scope character varying NOT NULL,
    scope_id character varying,
    indexed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.files OWNER TO therese;

--
-- Name: invoice_lines; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.invoice_lines (
    id character varying NOT NULL,
    invoice_id character varying NOT NULL,
    description character varying NOT NULL,
    quantity double precision NOT NULL,
    unit_price_ht double precision NOT NULL,
    tva_rate double precision NOT NULL,
    total_ht double precision NOT NULL,
    total_ttc double precision NOT NULL
);


ALTER TABLE public.invoice_lines OWNER TO therese;

--
-- Name: invoices; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.invoices (
    id character varying NOT NULL,
    user_id character varying,
    org_id character varying,
    invoice_number character varying NOT NULL,
    contact_id character varying NOT NULL,
    document_type character varying NOT NULL,
    tva_applicable boolean NOT NULL,
    currency character varying NOT NULL,
    issue_date timestamp without time zone NOT NULL,
    due_date timestamp without time zone NOT NULL,
    status character varying NOT NULL,
    subtotal_ht double precision NOT NULL,
    total_tax double precision NOT NULL,
    total_ttc double precision NOT NULL,
    notes character varying,
    payment_date timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.invoices OWNER TO therese;

--
-- Name: messages; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.messages (
    id character varying NOT NULL,
    conversation_id character varying NOT NULL,
    role character varying NOT NULL,
    content character varying NOT NULL,
    tokens_in integer,
    tokens_out integer,
    model character varying,
    extra_data character varying,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.messages OWNER TO therese;

--
-- Name: organizations; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.organizations (
    id character varying NOT NULL,
    name character varying NOT NULL,
    slug character varying NOT NULL,
    settings_json character varying,
    max_users integer NOT NULL,
    max_tokens_per_day integer NOT NULL,
    is_active boolean NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.organizations OWNER TO therese;

--
-- Name: preferences; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.preferences (
    id character varying NOT NULL,
    user_id character varying,
    org_id character varying,
    key character varying NOT NULL,
    value character varying NOT NULL,
    category character varying NOT NULL,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.preferences OWNER TO therese;

--
-- Name: projects; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.projects (
    id character varying NOT NULL,
    user_id character varying,
    org_id character varying,
    name character varying NOT NULL,
    description character varying,
    contact_id character varying,
    status character varying NOT NULL,
    budget double precision,
    notes character varying,
    tags character varying,
    extra_data character varying,
    scope character varying NOT NULL,
    scope_id character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.projects OWNER TO therese;

--
-- Name: prompt_templates; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.prompt_templates (
    id character varying NOT NULL,
    user_id character varying,
    org_id character varying,
    name character varying NOT NULL,
    prompt character varying NOT NULL,
    category character varying NOT NULL,
    icon character varying,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.prompt_templates OWNER TO therese;

--
-- Name: refresh_tokens; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.refresh_tokens (
    id character varying NOT NULL,
    user_id character varying NOT NULL,
    token character varying NOT NULL,
    expires_at timestamp without time zone NOT NULL,
    revoked boolean NOT NULL,
    created_at timestamp without time zone NOT NULL
);


ALTER TABLE public.refresh_tokens OWNER TO therese;

--
-- Name: tasks; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.tasks (
    id character varying NOT NULL,
    user_id character varying,
    org_id character varying,
    title character varying NOT NULL,
    description character varying,
    status character varying NOT NULL,
    priority character varying NOT NULL,
    due_date timestamp without time zone,
    project_id character varying,
    tags character varying,
    completed_at timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.tasks OWNER TO therese;

--
-- Name: users; Type: TABLE; Schema: public; Owner: therese
--

CREATE TABLE public.users (
    id character varying NOT NULL,
    email character varying NOT NULL,
    hashed_password character varying NOT NULL,
    name character varying NOT NULL,
    role character varying NOT NULL,
    org_id character varying NOT NULL,
    is_active boolean NOT NULL,
    is_verified boolean NOT NULL,
    is_superuser boolean NOT NULL,
    charter_accepted boolean NOT NULL,
    charter_accepted_at timestamp without time zone,
    last_login timestamp without time zone,
    created_at timestamp without time zone NOT NULL,
    updated_at timestamp without time zone NOT NULL
);


ALTER TABLE public.users OWNER TO therese;

--
-- Name: activity_logs id; Type: DEFAULT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.activity_logs ALTER COLUMN id SET DEFAULT nextval('public.activity_logs_id_seq'::regclass);


--
-- Data for Name: activities; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.activities (id, contact_id, type, title, description, extra_data, created_at) FROM stdin;
\.


--
-- Data for Name: activity_logs; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.activity_logs (id, "timestamp", action, resource_type, resource_id, details, ip_address, user_agent) FROM stdin;
\.


--
-- Data for Name: agent_messages; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.agent_messages (id, task_id, agent, role, content, tool_calls, created_at) FROM stdin;
\.


--
-- Data for Name: agent_tasks; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.agent_tasks (id, title, description, status, branch_name, source_path, diff_summary, diff_patch, files_changed, agent_model, tokens_used, cost_eur, error, created_at, updated_at, merged_at) FROM stdin;
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.audit_logs (id, user_id, org_id, user_email, action, resource, resource_id, details_json, ip_address, user_agent, "timestamp") FROM stdin;
b9f27ec1-a613-425f-b6d2-e4c57cdfc4f5	unknown	unknown	\N	login_failed	\N	\N	{"email": "wrong@test.fr"}	127.0.0.1	\N	2026-03-20 15:31:33.26711
7c630bd5-dcc9-4703-8de2-aae30f0a7c08	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-20 15:33:19.438457
7c3833ae-02d4-4e07-9b51-d2a0f3cce491	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-20 15:35:49.930004
24b37ab1-34f5-498c-a5e1-c617be0f7129	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-20 15:37:05.026314
77c57426-9956-49e6-8a31-8562266a4b18	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-20 16:36:20.991838
1de72927-b29b-4733-bd70-e2fa1f7f6842	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-20 17:08:20.552798
95af2b0b-58cf-4c33-9559-39146a0e3064	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-20 17:08:33.397195
b685cc21-af73-4b44-8cb1-42b3a425ada1	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-20 17:10:22.170452
3b8f3dfe-3de8-4d6a-8ae5-9f36f328e62b	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	user_created	users	e7f235e5-80f8-4e13-bcf0-3020b282b2be	{"email": "chef@therese.local", "role": "manager"}	\N	\N	2026-03-20 17:10:22.516373
2abbc098-5224-4a50-b754-cdd8b05b83c5	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-20 17:17:43.649754
901f073c-4fd1-4226-8708-219dd9290a93	e7f235e5-80f8-4e13-bcf0-3020b282b2be	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	chef@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-20 17:19:15.124787
c927449b-7724-4c4e-b93d-2933c099faf4	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-20 17:22:18.164974
3de60547-2744-4296-b196-4047be5cd782	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-20 17:52:30.072979
90dfa1bd-2d78-4af6-9e0c-061dffbc7b64	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-22 19:53:07.630113
e2231a4b-7a3b-49a1-94e7-90eed7749b1e	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-22 19:54:36.300833
4e5f8e95-602c-446e-b1be-9e7a9086be93	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-22 19:54:38.657721
c5411f5e-cf64-4a59-922c-b0a757b047cb	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-22 19:54:44.923188
d02647ff-8a9e-47a5-baec-e85815a6899e	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	user_created	users	9d1fd05a-09d6-4156-9364-45285f9d4ec8	{"email": "agent1.martin@mairie.local", "role": "agent"}	\N	\N	2026-03-22 19:54:45.291424
b2e59a50-a35a-4a05-853f-51cf7a4b0e4e	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	user_created	users	93ced295-12f7-4edd-994d-e6f8a08948c3	{"email": "agent2.dupont@mairie.local", "role": "agent"}	\N	\N	2026-03-22 19:54:45.61778
7c41c0d2-ea09-4921-a166-22b1b55dfad0	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-22 19:54:53.026471
679d9249-e83e-4b9f-8433-eef8dd26288b	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	admin@therese.local	user_created	users	40aff3ae-ec41-4d6d-b5eb-4283882297d0	{"email": "agent1@mairie.local", "role": "agent"}	\N	\N	2026-03-22 19:54:53.389768
4e889e66-52bd-44b3-ad1d-552a6f6a5494	9d1fd05a-09d6-4156-9364-45285f9d4ec8	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	agent1.martin@mairie.local	login	\N	\N	\N	127.0.0.1	\N	2026-03-22 19:54:56.709288
\.


--
-- Data for Name: board_decisions; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.board_decisions (id, user_id, org_id, question, context, opinions, synthesis, confidence, recommendation, mode, created_at) FROM stdin;
\.


--
-- Data for Name: calendar_events; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.calendar_events (id, calendar_id, summary, description, location, start_datetime, end_datetime, start_date, end_date, all_day, attendees, recurrence, status, synced_at) FROM stdin;
\.


--
-- Data for Name: calendars; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.calendars (id, user_id, org_id, account_id, summary, description, timezone, "primary", provider, remote_id, caldav_url, caldav_username, caldav_password, sync_status, last_sync_error, synced_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: code_changes; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.code_changes (id, task_id, file_path, change_type, diff_hunk, explanation, approved, created_at) FROM stdin;
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.contacts (id, user_id, org_id, first_name, last_name, company, email, phone, address, notes, tags, extra_data, stage, score, source, last_interaction, rgpd_base_legale, rgpd_date_collecte, rgpd_date_expiration, rgpd_consentement, scope, scope_id, created_at, updated_at) FROM stdin;
39cd1f3a-f4f3-4da6-ad82-a857675e61b3	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	\N	\N	\N	marie@mairie-test.fr	04 92 00 00 00	\N	\N	\N	\N	contact	50	\N	2026-03-20 17:08:33.697195	\N	\N	\N	f	global	\N	2026-03-20 17:08:33.697562	2026-03-20 17:08:33.697599
\.


--
-- Data for Name: conversations; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.conversations (id, user_id, org_id, title, summary, created_at, updated_at) FROM stdin;
90b07953-ed58-447e-be19-5eda150dc65e	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	Nouvelle conversation	\N	2026-03-20 15:33:55.967058	2026-03-20 16:40:18.733079
0efb0325-4733-4ae7-a33e-cbcb0c5837fc	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	Nouvelle conversation	\N	2026-03-20 16:48:20.886234	2026-03-20 16:52:40.959245
\.


--
-- Data for Name: deliverables; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.deliverables (id, project_id, title, description, status, due_date, completed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_accounts; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.email_accounts (id, user_id, org_id, email, provider, client_id, client_secret, access_token, refresh_token, token_expiry, scopes, imap_host, imap_port, imap_username, imap_password, smtp_host, smtp_port, smtp_use_tls, created_at, updated_at, last_sync) FROM stdin;
\.


--
-- Data for Name: email_labels; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.email_labels (id, account_id, name, type, color_background, color_text, messages_total, messages_unread, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: email_messages; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.email_messages (id, thread_id, account_id, subject, snippet, from_email, from_name, to_emails, cc_emails, bcc_emails, date, internal_date, labels, is_read, is_starred, is_important, is_draft, has_attachments, attachment_count, body_plain, body_html, size_bytes, synced_at, priority, priority_score, priority_reason, category) FROM stdin;
\.


--
-- Data for Name: files; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.files (id, user_id, org_id, path, name, extension, size, mime_type, content_hash, chunk_count, scope, scope_id, indexed_at, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: invoice_lines; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.invoice_lines (id, invoice_id, description, quantity, unit_price_ht, tva_rate, total_ht, total_ttc) FROM stdin;
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.invoices (id, user_id, org_id, invoice_number, contact_id, document_type, tva_applicable, currency, issue_date, due_date, status, subtotal_ht, total_tax, total_ttc, notes, payment_date, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: messages; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.messages (id, conversation_id, role, content, tokens_in, tokens_out, model, extra_data, created_at) FROM stdin;
ef1b1c4f-cec5-4bc2-a197-e026a987b43b	90b07953-ed58-447e-be19-5eda150dc65e	user	Bonjour Thérèse, ceci est un test de la version serveur !	\N	\N	\N	\N	2026-03-20 15:34:08.063723
9948ac8e-339c-4ff7-bd7a-a1d6bae30820	90b07953-ed58-447e-be19-5eda150dc65e	assistant	Aucun fournisseur LLM configuré. Ajoutez une clé API (ANTHROPIC_API_KEY, OPENAI_API_KEY) ou configurez Ollama dans le fichier .env	\N	\N	claude-sonnet-4-6	\N	2026-03-20 15:34:08.283829
510215d7-ea08-4ca3-aad3-b24d2f29b926	90b07953-ed58-447e-be19-5eda150dc65e	user	test	\N	\N	\N	\N	2026-03-20 16:40:18.732673
900b18ec-b713-4733-aac0-32508b17b97c	90b07953-ed58-447e-be19-5eda150dc65e	assistant	Aucun fournisseur LLM configuré. Ajoutez une clé API (ANTHROPIC_API_KEY, OPENAI_API_KEY) ou configurez Ollama dans le fichier .env	\N	\N	mistral:7b	\N	2026-03-20 16:40:18.763205
30f3f70b-857c-4ae1-a727-736eee2d4905	0efb0325-4733-4ae7-a33e-cbcb0c5837fc	user	Bonjour Thérèse ! Présente-toi en 2 phrases.	\N	\N	\N	\N	2026-03-20 16:48:50.489388
70e65682-7f89-4751-973e-63ec3d9223e6	0efb0325-4733-4ae7-a33e-cbcb0c5837fc	assistant	Bonjour ! Je suis Thérèse, une assistante IA professionnelle conçue pour accompagner les collectivités et PME françaises. Mon rôle est de vous fournir des informations précises et des conseils structurés pour optimiser vos activités.	\N	\N	gemini-2.5-flash	\N	2026-03-20 16:48:53.087746
40b6aa57-79f8-4218-8fc0-8058be155c6b	0efb0325-4733-4ae7-a33e-cbcb0c5837fc	user	Rédige un courrier administratif formel de la part de [service] à destination de [destinataire] concernant [sujet]. Ton professionnel, formules de politesse adaptées au secteur public.	\N	\N	\N	\N	2026-03-20 16:52:40.958938
9328bcaa-74ff-4a3d-ad5b-e65adead178c	0efb0325-4733-4ae7-a33e-cbcb0c5837fc	assistant	Absolument ! Voici un modèle de courrier administratif formel, prêt à être complété. J'ai utilisé les formules de politesse et le langage couramment employés dans le secteur public français.\n\n---\n\n**[Nom de l'Organisme Émetteur]**\n**[Service Émetteur]**\n[Adresse complète de l'Organisme]\n[Code Postal Ville]\nTéléphone : [Numéro de téléphone]\nCourriel : [Adresse e-mail]\n\n[Ville], le JJ Mois AAAA\n\n**Nos réf. :** [Référence interne du service émetteur, ex: DS/2024-XXX]\n**Votre réf. :** [Référence éventuelle du destinataire si réponse à un courrier, le cas échéant]\n\n**À Monsieur/Madame [Nom du Destinataire, ou Titre de la Fonction]**\n[Fonction du Destinataire]\n[Nom de l'Organisme Destinataire]\n[Adresse complète de l'Organisme Destinataire]\n[Code Postal Ville]\n\n**Objet :** [Sujet précis et concis du courrier]\n\nMonsieur/Madame [Nom du Destinataire, ou Titre de la Fonction],\n\nPar la présente, et suite à [préciser le contexte : une réunion du JJ/MM/AAAA, un échange téléphonique du JJ/MM/AAAA, votre courrier du JJ/MM/AAAA, etc.], le service [Nom du service émetteur] a l'honneur de vous informer/solliciter votre attention concernant [détailler l'objet du courrier].\n\n[Développer le corps du courrier en exposant les faits, les motivations, les demandes ou les informations à transmettre. Soyez clair, concis et factuel. Utilisez des paragraphes distincts pour chaque idée principale. Par exemple :\n*   "Nous souhaitons attirer votre vigilance sur [point précis]."\n*   "Dans le cadre de [projet/dossier], il nous apparaît nécessaire de [action/information requise]."\n*   "À ce titre, nous vous prions de bien vouloir [décrire l'action attendue ou la pièce jointe sollicitée]."\n*   "Les éléments ci-après vous apporteront des précisions utiles : [liste d'informations ou de points]."\n]\n\nNous restons naturellement à votre entière disposition pour toute information complémentaire que vous jugeriez utile.\n\nDans l'attente de votre retour et de la bonne suite que vous voudrez bien accorder à cette demande/information, je vous prie d'agréer, Monsieur/Madame [Nom du Destinataire, ou Titre de la Fonction], l'expression de ma parfaite considération.\n\nCordialement,\n\n**[Nom du Service Émetteur]**\n[Le/La Responsable du Service, ou Fonction du Signataire]\n[Prénom Nom du Signataire]\n\n**P.J. :** [Liste des pièces jointes, le cas échéant : ex: Copie de la délibération n°XX, Plan de situation, etc.]\n\n---\n\nN'hésitez pas à me donner les informations spécifiques (service, destinataire, sujet) et je pourrai le personnaliser davantage pour vous !	\N	\N	gemini-2.5-flash	\N	2026-03-20 16:52:52.271311
\.


--
-- Data for Name: organizations; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.organizations (id, name, slug, settings_json, max_users, max_tokens_per_day, is_active, created_at, updated_at) FROM stdin;
cfa7427c-6bf4-48a0-9d7f-71a2133ac502	Organisation par défaut	default	\N	100	100000	t	2026-03-20 15:29:41.070626	2026-03-20 15:29:41.070644
\.


--
-- Data for Name: preferences; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.preferences (id, user_id, org_id, key, value, category, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.projects (id, user_id, org_id, name, description, contact_id, status, budget, notes, tags, extra_data, scope, scope_id, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: prompt_templates; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.prompt_templates (id, user_id, org_id, name, prompt, category, icon, created_at, updated_at) FROM stdin;
2d251f0e-ba85-49c4-804d-bf0d972ba2e2	\N	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	Courrier administratif	Rédige un courrier administratif formel de la part de [service] à destination de [destinataire] concernant [sujet]. Ton professionnel, formules de politesse adaptées au secteur public.	courrier	Mail	2026-03-20 15:35:50.065395	2026-03-20 15:35:50.065438
d93800b4-25e0-4222-aa17-6a1a98869509	\N	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	Réponse à un administré	Rédige une réponse à un administré qui a écrit au sujet de [sujet]. La réponse doit être courtoise, claire et indiquer les prochaines étapes.	courrier	Mail	2026-03-20 15:35:50.065998	2026-03-20 15:35:50.066027
a374eb11-cd59-4619-ada1-9f2e0b5578ea	\N	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	Note de synthèse	Rédige une note de synthèse sur [sujet] à destination de [destinataire]. Structure : contexte, enjeux, analyse, recommandations. Maximum 2 pages.	synthese	ClipboardList	2026-03-20 15:35:50.066368	2026-03-20 15:35:50.066395
55bf14b8-7774-4490-a3c8-a703d73e3f63	\N	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	Compte-rendu de réunion	Rédige un compte-rendu structuré de la réunion du [date] portant sur [sujet]. Participants : [liste]. Inclure : points abordés, décisions prises, actions à mener avec responsables et délais.	note	FileText	2026-03-20 15:35:50.066675	2026-03-20 15:35:50.066698
b19b0432-0e39-4d5b-925f-8ea338d159c5	\N	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	Délibération du conseil	Rédige un projet de délibération pour le conseil municipal/d'administration portant sur [sujet]. Structure : visa des textes, exposé des motifs, dispositif (articles).	deliberation	Scale	2026-03-20 15:35:50.066967	2026-03-20 15:35:50.066991
5995c099-05c7-4a70-a5a8-41ddd4f2a184	\N	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	Communication interne	Rédige une note d'information interne à destination de [service/tous les agents] concernant [sujet]. Ton accessible, informations pratiques, dates clés.	communication	Megaphone	2026-03-20 15:35:50.067306	2026-03-20 15:35:50.067335
44a9845f-23be-4ade-bd1a-b36546638aa7	\N	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	Offre d'emploi	Rédige une offre d'emploi pour le poste de [intitulé] au sein de [service]. Inclure : missions, profil recherché, conditions (grade, rémunération), modalités de candidature.	rh	Users	2026-03-20 15:35:50.067593	2026-03-20 15:35:50.067616
d82b3ac3-f390-4f49-91a7-ef0cd8d8a9a2	\N	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	Synthèse de document	Résume le document suivant en [nombre] points clés. Identifie les informations essentielles, les décisions à prendre et les délais importants.	synthese	ClipboardList	2026-03-20 15:35:50.067838	2026-03-20 15:35:50.067861
38d1fd99-e415-4c39-8edb-63d59fb42b96	\N	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	Email professionnel	Rédige un email professionnel à [destinataire] concernant [sujet]. Ton : [formel/cordial]. Objectif : [informer/demander/confirmer].	communication	Megaphone	2026-03-20 15:35:50.068089	2026-03-20 15:35:50.068113
0938252e-981a-4f54-bafd-9fa69df63089	\N	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	Analyse comparative	Réalise une analyse comparative entre [option A] et [option B] pour [contexte]. Structure en tableau avec critères : coût, délai, avantages, inconvénients, recommandation.	general	Sparkles	2026-03-20 15:35:50.068359	2026-03-20 15:35:50.068381
\.


--
-- Data for Name: refresh_tokens; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.refresh_tokens (id, user_id, token, expires_at, revoked, created_at) FROM stdin;
dc3221fb-714c-4291-83a3-ad4e32d4266b	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	KOox_r0mopQtyjfN3MHhIHszPhvYshvWT-nn6QMJA44GIBx4x4bGOVCU1YWHpGb0eM3QN200263PNjjfnypkwg	2026-03-27 15:33:19.425624	f	2026-03-20 15:33:19.426014
3d123ba6-48e8-4f5a-81f1-fad1470fd369	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	gLy_k3nl2o5EBVuDNFiLRf-i74HTVCZEiD2n4-JMVbF7H9KUQVqp6U2yP_2X9RMkJbsz-6zMjHSwZm4D932a9w	2026-03-27 15:35:49.923093	f	2026-03-20 15:35:49.923572
58d1caa2-0129-4417-a615-0f573022d011	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	U_aiPprtNmu7qyyLsld22Kf60LeZOQYTxkBnFN2G34fHU4G26tmw1h43xmeVHcuOUQhKouf1tObt186POyAttQ	2026-03-27 15:37:05.021625	f	2026-03-20 15:37:05.022006
b1600969-aea2-4163-9da1-384cc7fccfe6	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	YO5AkIgvPS9sW_6ZY7Fz2Mj_kdEfHZK823dIYhk-RQyIetAoQuYnNDbbz2G-LQNBY-8bTCz3PUekvzck2LXKCw	2026-03-27 16:36:20.938617	f	2026-03-20 16:36:20.939027
acf5ca1c-021f-41f9-b467-19d33f9a6b05	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	FhHSws1_Wlqf2nCFphJ-jecbIVJ9hnQHMpb89RcyI7e5UqC4D_3zDcn8WMXZ3i26rgNQnV3wg2wEMafofRnqoA	2026-03-27 17:08:20.543621	f	2026-03-20 17:08:20.543886
86189a23-04db-46d4-a236-1ac128007f7b	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	-fclTpGobDL-45uz-R5Qej6p6gTQvQwUfZwgxCKsYxRuT6Y85c33Okutf0puL3nsW0WxcJ2DowZ20G7IPHa_Fg	2026-03-27 17:08:33.392622	f	2026-03-20 17:08:33.392838
d9acf5bb-5b3b-4872-8ab2-94516f3b460f	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	SrFENTMqYSLjQez0oAVhyWfNAUkSFg5M_aUNdAkqyHcQ6iv8vtzzR7P_hb68xKBGuFg8c4djiOp-1h9BEF7Ulw	2026-03-27 17:10:22.164714	f	2026-03-20 17:10:22.165034
026dbfeb-e2f9-442c-9896-847462ba839e	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	WA5CFBYiQdcYF5ANXV2ZTc2ivuD6wnQ78fbFJLmBWnKzHyVtM11Lq3_12AGLByT75o8DuwuOR7mH2dK5Y_dgzg	2026-03-27 17:17:43.643947	f	2026-03-20 17:17:43.644441
a53ea5ba-fe3a-4ad8-a765-1c48fa16fc04	e7f235e5-80f8-4e13-bcf0-3020b282b2be	YEmKIARB_UcPE7Te5zYUbj56GP4iO7AQPAVSAl4ui-eK8Sb6ImwPR8XDrsdS7anE6w0LzzpGcv6rGH93rWk9dQ	2026-03-27 17:19:15.112739	f	2026-03-20 17:19:15.113037
b5abc247-13a8-4ccc-b2a8-53c0b068b170	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	zKlElzau197pSnngD5sigYr7t8T1m-81D-xD9OD49viJq1KCdzss0lRVMbSUZES9DUFUo6_EL3RKkJ4K9SkMug	2026-03-27 17:22:18.159973	f	2026-03-20 17:22:18.160363
e66ddea9-3bd7-4ed7-938d-c3e898deef9d	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	f48rrBcbOfisTSDyZZeLlcjY0LP8PIAHNSGOd23xyBWQessolJSQi6-zpYzbwkRix7wHalGZMzd4tPP3zrIOiA	2026-03-27 17:52:30.060494	f	2026-03-20 17:52:30.060864
f899f861-b329-4ca6-a597-f87015620494	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	rH6XRZhkXPrFS_x4ucA6LseaYoQKe6buNTI5z_mebIlnAgwccmAqfdayusJ132QplPtrBWBfO9aBq_4C6q9A8g	2026-03-29 19:53:07.615778	f	2026-03-22 19:53:07.616584
db65d457-8206-4f67-b8bd-9f574c3577ce	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	ub2tMzbIME6_Lus6kMQAV-OPS9TPhPuybF391GktLS7pNmq0v4ti-nP7SxjJSP4snSgxw-KO9L3tMmWwsBJLhA	2026-03-29 19:54:36.294613	f	2026-03-22 19:54:36.295069
187c1850-4903-4500-aa9b-c63e435b2417	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	d5yT832NzvGQFiVVGLNJ5yq4b3OU-wFT3fiU3rC-CJgso77H5xqX4XRQ-Q9HHthUVWLYLA-amqlWrLBw-Fpm-A	2026-03-29 19:54:38.652819	f	2026-03-22 19:54:38.653062
8a48a2aa-6a15-4e3e-a7b3-29d356b07a18	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	BwkskkAjir_5k-FXCGFOLvNlp1kMfyJL1W46eQQbsx698fITPwVegZMH_Q43A68PxbTIUPpHnB3-V8D0uKXLfA	2026-03-29 19:54:44.917763	f	2026-03-22 19:54:44.918057
4f6e8e09-b688-45dd-a2e0-edf4e3d15e28	88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	qG9LQtNYV-A9B_jwbK7Lsck-fIWojne8m5B1YhDMKvtUKj0774vTNnHxbOgCQNNNOXIVSRT28a6kSUlslObz4Q	2026-03-29 19:54:53.021344	f	2026-03-22 19:54:53.021664
db13e6a7-9a6e-42ed-a3e4-b3105a66bc01	9d1fd05a-09d6-4156-9364-45285f9d4ec8	SplDyW-tJA0dgK16xnnc5b-iEGh1rBBGm7gW29w-Gu9yW5T2BwDJtLpZov2Rk0yw2ULaWK4DL238VHY77F2sUQ	2026-03-29 19:54:56.703936	f	2026-03-22 19:54:56.704212
\.


--
-- Data for Name: tasks; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.tasks (id, user_id, org_id, title, description, status, priority, due_date, project_id, tags, completed_at, created_at, updated_at) FROM stdin;
57dc68c2-ccff-4a7d-adbb-6c2cb3a5dab6	\N	\N	Tester tous les endpoints	Verifier que les 143 routes fonctionnent	todo	high	\N	\N	[]	\N	2026-03-20 17:08:33.586586	2026-03-20 17:08:33.586596
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: therese
--

COPY public.users (id, email, hashed_password, name, role, org_id, is_active, is_verified, is_superuser, charter_accepted, charter_accepted_at, last_login, created_at, updated_at) FROM stdin;
e7f235e5-80f8-4e13-bcf0-3020b282b2be	chef@therese.local	$2b$12$4.KjAGoMkV4nVEMpZ3XlCu2mVHQrdQK649KWWhyh.p6JjUlHd78.6	Jean Martin	manager	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	t	f	f	t	2026-03-20 17:19:28.709524	2026-03-20 17:19:15.104375	2026-03-20 17:10:22.496211	2026-03-20 17:10:22.496241
93ced295-12f7-4edd-994d-e6f8a08948c3	agent2.dupont@mairie.local	$2b$12$WuYya8wlyhtSKWTdH2b4tOPF9Q9vG03FfAUyoos3YVM1Qdj4Bwr.u	Dupont	agent	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	t	f	f	f	\N	\N	2026-03-22 19:54:45.608438	2026-03-22 19:54:45.60846
88d9bae3-2cf9-49d7-8b89-37ff3bb4f6ee	admin@therese.local	$2b$12$iAPZmGLKA2REEvCQcHa.JuGooVn7o.sxqj770ddjJlHhu2/mH7JQC	Administrateur	admin	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	t	t	t	t	2026-03-20 15:33:36.145784	2026-03-22 19:54:53.016051	2026-03-20 15:29:41.335599	2026-03-20 15:29:41.335618
40aff3ae-ec41-4d6d-b5eb-4283882297d0	agent1@mairie.local	$2b$12$uUkMbQ488wkC04b5G55LneKAsY3EfgFko1udUlfQ6sasulCNqoG02	Agent Accueil 1	agent	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	t	f	f	f	\N	\N	2026-03-22 19:54:53.376868	2026-03-22 19:54:53.376922
9d1fd05a-09d6-4156-9364-45285f9d4ec8	agent1.martin@mairie.local	$2b$12$b0AlCCWHTHVRgElQeZf9Xu8TNrzoSBj02gRse7nXc0EuFva3./WNW	Martin	agent	cfa7427c-6bf4-48a0-9d7f-71a2133ac502	t	f	f	f	\N	2026-03-22 19:54:56.697366	2026-03-22 19:54:45.276122	2026-03-22 19:54:45.276164
\.


--
-- Name: activity_logs_id_seq; Type: SEQUENCE SET; Schema: public; Owner: therese
--

SELECT pg_catalog.setval('public.activity_logs_id_seq', 1, false);


--
-- Name: activities activities_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_pkey PRIMARY KEY (id);


--
-- Name: activity_logs activity_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.activity_logs
    ADD CONSTRAINT activity_logs_pkey PRIMARY KEY (id);


--
-- Name: agent_messages agent_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_pkey PRIMARY KEY (id);


--
-- Name: agent_tasks agent_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.agent_tasks
    ADD CONSTRAINT agent_tasks_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: board_decisions board_decisions_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.board_decisions
    ADD CONSTRAINT board_decisions_pkey PRIMARY KEY (id);


--
-- Name: calendar_events calendar_events_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_pkey PRIMARY KEY (id);


--
-- Name: calendars calendars_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.calendars
    ADD CONSTRAINT calendars_pkey PRIMARY KEY (id);


--
-- Name: code_changes code_changes_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.code_changes
    ADD CONSTRAINT code_changes_pkey PRIMARY KEY (id);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: conversations conversations_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_pkey PRIMARY KEY (id);


--
-- Name: deliverables deliverables_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.deliverables
    ADD CONSTRAINT deliverables_pkey PRIMARY KEY (id);


--
-- Name: email_accounts email_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.email_accounts
    ADD CONSTRAINT email_accounts_pkey PRIMARY KEY (id);


--
-- Name: email_labels email_labels_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.email_labels
    ADD CONSTRAINT email_labels_pkey PRIMARY KEY (id);


--
-- Name: email_messages email_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.email_messages
    ADD CONSTRAINT email_messages_pkey PRIMARY KEY (id);


--
-- Name: files files_path_key; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_path_key UNIQUE (path);


--
-- Name: files files_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_pkey PRIMARY KEY (id);


--
-- Name: invoice_lines invoice_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.invoice_lines
    ADD CONSTRAINT invoice_lines_pkey PRIMARY KEY (id);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: messages messages_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_pkey PRIMARY KEY (id);


--
-- Name: organizations organizations_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.organizations
    ADD CONSTRAINT organizations_pkey PRIMARY KEY (id);


--
-- Name: preferences preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.preferences
    ADD CONSTRAINT preferences_pkey PRIMARY KEY (id);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: prompt_templates prompt_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.prompt_templates
    ADD CONSTRAINT prompt_templates_pkey PRIMARY KEY (id);


--
-- Name: refresh_tokens refresh_tokens_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_pkey PRIMARY KEY (id);


--
-- Name: tasks tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_pkey PRIMARY KEY (id);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: ix_activities_contact_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_activities_contact_id ON public.activities USING btree (contact_id);


--
-- Name: ix_activity_logs_action; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_activity_logs_action ON public.activity_logs USING btree (action);


--
-- Name: ix_activity_logs_timestamp; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_activity_logs_timestamp ON public.activity_logs USING btree ("timestamp");


--
-- Name: ix_agent_messages_task_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_agent_messages_task_id ON public.agent_messages USING btree (task_id);


--
-- Name: ix_agent_tasks_status; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_agent_tasks_status ON public.agent_tasks USING btree (status);


--
-- Name: ix_audit_logs_action; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_audit_logs_action ON public.audit_logs USING btree (action);


--
-- Name: ix_audit_logs_org_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_audit_logs_org_id ON public.audit_logs USING btree (org_id);


--
-- Name: ix_audit_logs_timestamp; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_audit_logs_timestamp ON public.audit_logs USING btree ("timestamp");


--
-- Name: ix_audit_logs_user_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_audit_logs_user_id ON public.audit_logs USING btree (user_id);


--
-- Name: ix_board_decisions_created_at; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_board_decisions_created_at ON public.board_decisions USING btree (created_at);


--
-- Name: ix_board_decisions_org_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_board_decisions_org_id ON public.board_decisions USING btree (org_id);


--
-- Name: ix_board_decisions_user_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_board_decisions_user_id ON public.board_decisions USING btree (user_id);


--
-- Name: ix_calendar_events_calendar_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_calendar_events_calendar_id ON public.calendar_events USING btree (calendar_id);


--
-- Name: ix_calendars_account_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_calendars_account_id ON public.calendars USING btree (account_id);


--
-- Name: ix_calendars_org_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_calendars_org_id ON public.calendars USING btree (org_id);


--
-- Name: ix_calendars_user_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_calendars_user_id ON public.calendars USING btree (user_id);


--
-- Name: ix_code_changes_task_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_code_changes_task_id ON public.code_changes USING btree (task_id);


--
-- Name: ix_contacts_email; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_contacts_email ON public.contacts USING btree (email);


--
-- Name: ix_contacts_last_interaction; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_contacts_last_interaction ON public.contacts USING btree (last_interaction);


--
-- Name: ix_contacts_org_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_contacts_org_id ON public.contacts USING btree (org_id);


--
-- Name: ix_contacts_scope; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_contacts_scope ON public.contacts USING btree (scope);


--
-- Name: ix_contacts_stage; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_contacts_stage ON public.contacts USING btree (stage);


--
-- Name: ix_contacts_user_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_contacts_user_id ON public.contacts USING btree (user_id);


--
-- Name: ix_conversations_created_at; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_conversations_created_at ON public.conversations USING btree (created_at);


--
-- Name: ix_conversations_org_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_conversations_org_id ON public.conversations USING btree (org_id);


--
-- Name: ix_conversations_updated_at; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_conversations_updated_at ON public.conversations USING btree (updated_at);


--
-- Name: ix_conversations_user_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_conversations_user_id ON public.conversations USING btree (user_id);


--
-- Name: ix_deliverables_project_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_deliverables_project_id ON public.deliverables USING btree (project_id);


--
-- Name: ix_email_accounts_email; Type: INDEX; Schema: public; Owner: therese
--

CREATE UNIQUE INDEX ix_email_accounts_email ON public.email_accounts USING btree (email);


--
-- Name: ix_email_accounts_org_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_email_accounts_org_id ON public.email_accounts USING btree (org_id);


--
-- Name: ix_email_accounts_user_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_email_accounts_user_id ON public.email_accounts USING btree (user_id);


--
-- Name: ix_email_labels_account_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_email_labels_account_id ON public.email_labels USING btree (account_id);


--
-- Name: ix_email_messages_account_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_email_messages_account_id ON public.email_messages USING btree (account_id);


--
-- Name: ix_email_messages_date; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_email_messages_date ON public.email_messages USING btree (date);


--
-- Name: ix_email_messages_priority; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_email_messages_priority ON public.email_messages USING btree (priority);


--
-- Name: ix_email_messages_thread_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_email_messages_thread_id ON public.email_messages USING btree (thread_id);


--
-- Name: ix_files_org_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_files_org_id ON public.files USING btree (org_id);


--
-- Name: ix_files_user_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_files_user_id ON public.files USING btree (user_id);


--
-- Name: ix_invoice_lines_invoice_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_invoice_lines_invoice_id ON public.invoice_lines USING btree (invoice_id);


--
-- Name: ix_invoices_contact_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_invoices_contact_id ON public.invoices USING btree (contact_id);


--
-- Name: ix_invoices_document_type; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_invoices_document_type ON public.invoices USING btree (document_type);


--
-- Name: ix_invoices_invoice_number; Type: INDEX; Schema: public; Owner: therese
--

CREATE UNIQUE INDEX ix_invoices_invoice_number ON public.invoices USING btree (invoice_number);


--
-- Name: ix_invoices_org_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_invoices_org_id ON public.invoices USING btree (org_id);


--
-- Name: ix_invoices_user_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_invoices_user_id ON public.invoices USING btree (user_id);


--
-- Name: ix_messages_conversation_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_messages_conversation_id ON public.messages USING btree (conversation_id);


--
-- Name: ix_messages_created_at; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_messages_created_at ON public.messages USING btree (created_at);


--
-- Name: ix_organizations_name; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_organizations_name ON public.organizations USING btree (name);


--
-- Name: ix_organizations_slug; Type: INDEX; Schema: public; Owner: therese
--

CREATE UNIQUE INDEX ix_organizations_slug ON public.organizations USING btree (slug);


--
-- Name: ix_preferences_key; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_preferences_key ON public.preferences USING btree (key);


--
-- Name: ix_preferences_org_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_preferences_org_id ON public.preferences USING btree (org_id);


--
-- Name: ix_preferences_user_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_preferences_user_id ON public.preferences USING btree (user_id);


--
-- Name: ix_projects_contact_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_projects_contact_id ON public.projects USING btree (contact_id);


--
-- Name: ix_projects_org_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_projects_org_id ON public.projects USING btree (org_id);


--
-- Name: ix_projects_scope; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_projects_scope ON public.projects USING btree (scope);


--
-- Name: ix_projects_user_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_projects_user_id ON public.projects USING btree (user_id);


--
-- Name: ix_prompt_templates_org_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_prompt_templates_org_id ON public.prompt_templates USING btree (org_id);


--
-- Name: ix_prompt_templates_user_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_prompt_templates_user_id ON public.prompt_templates USING btree (user_id);


--
-- Name: ix_refresh_tokens_token; Type: INDEX; Schema: public; Owner: therese
--

CREATE UNIQUE INDEX ix_refresh_tokens_token ON public.refresh_tokens USING btree (token);


--
-- Name: ix_refresh_tokens_user_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_refresh_tokens_user_id ON public.refresh_tokens USING btree (user_id);


--
-- Name: ix_tasks_org_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_tasks_org_id ON public.tasks USING btree (org_id);


--
-- Name: ix_tasks_project_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_tasks_project_id ON public.tasks USING btree (project_id);


--
-- Name: ix_tasks_user_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_tasks_user_id ON public.tasks USING btree (user_id);


--
-- Name: ix_users_email; Type: INDEX; Schema: public; Owner: therese
--

CREATE UNIQUE INDEX ix_users_email ON public.users USING btree (email);


--
-- Name: ix_users_org_id; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_users_org_id ON public.users USING btree (org_id);


--
-- Name: ix_users_role; Type: INDEX; Schema: public; Owner: therese
--

CREATE INDEX ix_users_role ON public.users USING btree (role);


--
-- Name: activities activities_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.activities
    ADD CONSTRAINT activities_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id);


--
-- Name: agent_messages agent_messages_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.agent_messages
    ADD CONSTRAINT agent_messages_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.agent_tasks(id);


--
-- Name: board_decisions board_decisions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.board_decisions
    ADD CONSTRAINT board_decisions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: calendar_events calendar_events_calendar_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.calendar_events
    ADD CONSTRAINT calendar_events_calendar_id_fkey FOREIGN KEY (calendar_id) REFERENCES public.calendars(id);


--
-- Name: calendars calendars_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.calendars
    ADD CONSTRAINT calendars_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.email_accounts(id);


--
-- Name: calendars calendars_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.calendars
    ADD CONSTRAINT calendars_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: code_changes code_changes_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.code_changes
    ADD CONSTRAINT code_changes_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.agent_tasks(id);


--
-- Name: contacts contacts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: conversations conversations_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.conversations
    ADD CONSTRAINT conversations_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: deliverables deliverables_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.deliverables
    ADD CONSTRAINT deliverables_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: email_accounts email_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.email_accounts
    ADD CONSTRAINT email_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: email_labels email_labels_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.email_labels
    ADD CONSTRAINT email_labels_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.email_accounts(id);


--
-- Name: email_messages email_messages_account_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.email_messages
    ADD CONSTRAINT email_messages_account_id_fkey FOREIGN KEY (account_id) REFERENCES public.email_accounts(id);


--
-- Name: files files_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.files
    ADD CONSTRAINT files_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: invoice_lines invoice_lines_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.invoice_lines
    ADD CONSTRAINT invoice_lines_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id);


--
-- Name: invoices invoices_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id);


--
-- Name: invoices invoices_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: messages messages_conversation_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.messages
    ADD CONSTRAINT messages_conversation_id_fkey FOREIGN KEY (conversation_id) REFERENCES public.conversations(id);


--
-- Name: preferences preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.preferences
    ADD CONSTRAINT preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: projects projects_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id);


--
-- Name: projects projects_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: prompt_templates prompt_templates_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.prompt_templates
    ADD CONSTRAINT prompt_templates_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: refresh_tokens refresh_tokens_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.refresh_tokens
    ADD CONSTRAINT refresh_tokens_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: tasks tasks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id);


--
-- Name: tasks tasks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.tasks
    ADD CONSTRAINT tasks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: users users_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: therese
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.organizations(id);


--
-- PostgreSQL database dump complete
--

\unrestrict eDAEehIKNzzMKM7heMiiE8PtY2g5B22ai1AxvgglDEeEiPeAb1KYWvPavDUZCIZ

